import usb_hid
from adafruit_hid.keyboard import Keyboard
from adafruit_hid.keyboard_layout_us import KeyboardLayoutUS
from adafruit_hid.keycode import Keycode
from adafruit_hid.consumer_control import ConsumerControl
from adafruit_hid.consumer_control_code import ConsumerControlCode
import time

# TR: Klavye ve ses kontrolu baslatiliyor
# EN: Initializing keyboard and volume control
kbd = Keyboard(usb_hid.devices)
layout = KeyboardLayoutUS(kbd)
cc = ConsumerControl(usb_hid.devices)

# TR: 100ms baslangic bekleme
# EN: 100ms startup wait
time.sleep(0.1)

# TR: Sesi tamamen fullar (50 kere volume up = kesinlikle max)
# EN: Maxes out volume (50x volume up = definitely max)
for i in range(50):
    cc.send(ConsumerControlCode.VOLUME_INCREMENT)
    time.sleep(0.01)  # TR: Her adim arasi 10ms / EN: 10ms between each step

# TR: Win+R ile calistir penceresi ac
# EN: Open Run dialog with Win+R
kbd.press(Keycode.WINDOWS, Keycode.R)
kbd.release_all()
time.sleep(0.4)  # TR: Pencerenin acilmasini bekle / EN: Wait for window to open

# TR: YouTube'da Look At Me ac
# EN: Open Look At Me on YouTube
layout.write("https://www.youtube.com/watch?v=bxWxXncl5XE\n")
